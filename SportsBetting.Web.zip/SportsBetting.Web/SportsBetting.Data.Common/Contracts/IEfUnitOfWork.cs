﻿namespace SportsBetting.Data.Common.Contracts
{
    public interface IEfUnitOfWork
    {
        void Commit();
    }
}
